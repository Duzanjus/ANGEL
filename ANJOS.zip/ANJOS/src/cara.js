const cara = (pushname, prefix, botName, ownerName) => { 
	return `🔰 -----[ *GUIA DE USUARIO ${botName}* ]----- 🔰
OL�, ${pushname} 👋
Aqui est� como us�-lo *${botName}*
         ────────────────
Se voc� n�o entende, leia primeiro -_-
         ────────────────
➸ *${prefix}sticker*
Envie fotos / v�deos com adesivos de legenda
➸ *${prefix}ttp*
Texto para adesivo Exemplo : ${prefix}ttp Anjos gostoso
➸ *${prefix}tts*
Exemplo de voz do Google : ${prefix}tts id Anjos gostoso
➸ *${prefix}toimg*
Responda ao adesivo que voc� deseja transformar na imagem
➸ *${prefix}nulis*
Escrever um livro
➸ *${prefix}stalkig*
Stalking Instagram exemplo : ${prefix}stalkig iamramlan_
➸ *${prefix}quotes*
Cita��es aleat�rias
➸ *${prefix}bikinquote*
Crie cita��es de exemplo : ${prefix}bikinquote Anjos gostoso
➸ *${prefix}play*
Baixar m�sicas do YouTube pode usar texto ou links
➸ *${prefix}yutubdl*
Baixe v�deos do YouTube, use o link, mana
➸ *${prefix}tiktod*
Baixe o v�deo do tiktok, use o link kak
➸ *${prefix}hartatahta*
Fa�a logo, por exemplo : ${prefix}hartatahta NADIA
➸ *${prefix}pornhub*
Crie um logotipo, por exemplo : ${prefix}pornhub Anjos Gostoso
Nota : para criador de logotipo / criador de imagem, se indefinido significa que voc� deve us�-lo &
➸ *${prefix}fitnah*
Grupo �nico para caluniar pessoas, por exemplo : ${prefix}fitnah @tagtarget & Hai & Hai juga
➸ *${prefix}mutual*
N�mero da Gacha que est� no banco de dados / quem usa o bot
         ────────────────
Nota: o resto � para o seu c�rebro, s� n�o consigo explicar :)
         ────────────────
🔰 -----[ *FEITO BY ANJOS ID* ]----- 🔰
`
}

exports.cara = cara