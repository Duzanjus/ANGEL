exports.wait = () => {
	return`*「❗」ESPERE SEU GAY*`
}

exports.succes = () => {
	return`*「 SUCESSO 」*`
}

exports.lvlon = () => {
	return`*「❗」ATIVAR NIVELAMENTO*`
}

exports.lvloff = () => {
	return`*「❗」DESATIVAR NIVELAMENTO*`
}

exports.lvlnul = () => {
	return`*「❗」SEU NÍVEL AINDA ESTA VAZIO*`
}

exports.lvlnoon = () => {
	return`*「❗」O NIVEL DO GRUB NAO FOI ATIVADO*`
}

exports.noregis = () => {
	return`*「❗」NAO REGISTRADO*\n*como registrar ${prefix}daftar nome|idade* \n\n*exemplo ${prefix}daftar ANJOS|18*`
}

exports.baned = () => {
	return`*「❗」SORRY SORRY AJA NIH BRO, MAS VOCE JA ESTA PROIBIDO YAHAHAHA HAYUUU :V*`
}

exports.premium = () => {
	return`*「❗」Desculpe, voce nao e um usuario premium ! entre em contato com o proprietario para ser de tipo premium ${prefix}owner*`
}

exports.rediregis = () => {
	return`*「 JA REGISTRADO 」*\n\n*voce registrou irmao >_<*`
}

exports.stikga = () => {
	return`*「 FALHOU 」Tentar repita na proxima vez mana*`
}

exports.linkga = () => {
	return`*「❗」desculpe o link e invalido sis*`
}

exports.groupo = () => {
	return`*「❗」SO EM GRUPO*`
}

exports.ownerb = () => {
	return`*「❗」DONO DO BOT APENAS*`
}

exports.ownerg = () => {
	return`*「❗」DONO DO GRUPO APENAS*`
}

exports.admin = () => {
	return`*「❗」ADMIN DO GRUPO APENAS*`
}

exports.badmin = () => {
	return`*「❗」O BOT DEVE SER ADMINISTRADOR*`
}

exports.nsfwoff = () => {
	return`*「❗」NSFW EM ATIVO*`
}

exports.bug = () => {
	return`*O problema foi relatado ao proprietario de BOT, relatorios falsos/main2 tidak akan ditanggapi*`
}

exports.wrongf = () => {
	return`*「🤔」Cade o texto mana?*`
}

exports.clears = () => {
	return`*「🚮」Limpar todo o sucesso*`
}

exports.pc = () => {
	return`*「❗」CADASTRO*\n\n para saber se voce se cadastrou, verifique a mensagem que enviei \n\nNOTA:\n*se você nao entendeu a mensagem. significa que voce nao salvou o número de seu bot*`
}

exports.registered = (namaUser, umurUser, serialUser, time, sender, botName) => {
	return`*「 REGISTRO DE SUCESSO 」*\nPara Informacoes De Usuario :\n\n*➸ Nome : ${namaUser}*\n*➸ Numero : wa.me/${sender.split("@")[0]}*\n*➸ Idade : ${umurUser}*\n*➸ Hora Do Registro : ${time}*\n\n*「SN」: ${serialUser}*\n_NOTA : Você é muito gay :v_`
}

exports.cmdnf = (prefix, command) => {
	return`command *${prefix}${command}* tidak di temukan\coba tulis *${prefix}menu*`
}

exports.owneresce = (pushname) => {
	return`*maaf tapi ${pushname} bukan owner script*`
}
exports.levelup = (pushname, sender, getLevelingXp,  getLevel, getLevelingLevel) => {
	return`
*「 FELIZ 」*
➸ *Nome* : ${pushname}
➸ *Numero* : wa.me/${sender.split("@")[0]}
➸ *Grana* : ${getLevelingXp(sender)}
➸ *Level* : ${getLevel} ➸ ${getLevelingLevel(sender)}
`}
 
exports.limitend = (pushname) => {
	return`*maaf ${pushname} O limite de hoje aumentou*\n*O limite e zerado a cada hora 24:00*`
}

exports.limitcount = (limitCounts) => {
	return`
*「 LIMITE CONTA 」*
sisa limit anda : ${limitCounts}

Melhoria premium meu chefe, biar bebas gunain bot`
}

exports.satukos = () => {
	return`*Parâmetro Adicionar 1/habilitar ou 0/desabilitar`
}

exports.uangkau = (pushname, sender, uangkau) => {
	return`┏━━━━━━━♡ *ATM* ♡━━━━━━━┓\n┃╭───────────────────\n┃│➸ NOME : ${pushname}\n┃│➸ NÚMERO : ${sender.split("@")[0]}\n┃│➸ DINHEIRO : ${uangkau}\n┃╰───────────────────\n┗━━━━━━━━━━━━━━━━━━━━┛`
}
