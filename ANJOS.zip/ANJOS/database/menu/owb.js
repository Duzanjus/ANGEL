const owb = (pushname, prefix, botName, ownerName, getLevelingLevel, sender, _registered) => {
	return `*࿅᪣ᬼ࿅𝔹𝕆𝕋ீ͜ৡৢ͜͡𝔸ℕ𝕁𝕆𝕊᪣ᬽ

OLÁ, ${pushname} 👋 MEU/MINHA COMPATRIOTA

■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙ＳＯＢＲＥ ＶＯＣÊ
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋╭┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅   
▋┋*NOME : *${pushname}
▋┋*DINHEIRO : Rp:*${uangku}
▋┋*XP : *${reqXp}
▋┋*LEVEL : *${getLevelingLevel(sender)}
▋┋*USUÁRIO : *${botName} : ${_registered.length}
▋┋*NÚMERO : *${sender.split("@")[0]}
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙ＡＪＵＤＡ
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋ Se você não entendeu os comandos, digitar:
▋┋*AJUDA: *${prefix}bingungcok*
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙ＳＯＭＥＮＴＥ ＤＯＮＯ
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋*${prefix}bc*
▋┋*${prefix}bcgc*
▋┋*${prefix}clearall*
▋┋*${prefix}block*
▋┋*${prefix}unblock*
▋┋*${prefix}clone*
▋┋*${prefix}setppbot*
▋┋*${prefix}setreply*
▋┋*${prefix}setprefix*
▋┋*${prefix}addprem*
▋┋*${prefix}dellprem*
▋┋*${prefix}ban*
▋┋*${prefix}unban*
▋┋*${prefix}resetlimit*
▋┋*${prefix}event* 「1/0」
■█■█■█■▰▱▰▱▰▱■█■█■█■

▋┋ *FEITO BY ${ownerName}* ]▋┋`
}
exports.owb = owb