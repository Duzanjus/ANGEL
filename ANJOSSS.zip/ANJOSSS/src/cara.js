const cara = (pushname, prefix, botName, ownerName) => { 
	return `ðŸ”° -----[ *GUIA DE USUARIO ${botName}* ]----- ðŸ”°
OLÁ, ${pushname} ðŸ‘‹
Aqui está como usá-lo *${botName}*
         â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
Se você não entende, leia primeiro -_-
         â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
âž¸ *${prefix}sticker*
Envie fotos / vídeos com adesivos de legenda
âž¸ *${prefix}ttp*
Texto para adesivo Exemplo : ${prefix}ttp Anjos gostoso
âž¸ *${prefix}tts*
Exemplo de voz do Google : ${prefix}tts id Anjos gostoso
âž¸ *${prefix}toimg*
Responda ao adesivo que você deseja transformar na imagem
âž¸ *${prefix}nulis*
Escrever um livro
âž¸ *${prefix}stalkig*
Stalking Instagram exemplo : ${prefix}stalkig iamramlan_
âž¸ *${prefix}quotes*
Citações aleatórias
âž¸ *${prefix}bikinquote*
Crie citações de exemplo : ${prefix}bikinquote Anjos gostoso
âž¸ *${prefix}play*
Baixar músicas do YouTube pode usar texto ou links
âž¸ *${prefix}yutubdl*
Baixe vídeos do YouTube, use o link, mana
âž¸ *${prefix}tiktod*
Baixe o vídeo do tiktok, use o link kak
âž¸ *${prefix}hartatahta*
Faça logo, por exemplo : ${prefix}hartatahta NADIA
âž¸ *${prefix}pornhub*
Crie um logotipo, por exemplo : ${prefix}pornhub Anjos Gostoso
Nota : para criador de logotipo / criador de imagem, se indefinido significa que você deve usá-lo &
âž¸ *${prefix}fitnah*
Grupo único para caluniar pessoas, por exemplo : ${prefix}fitnah @tagtarget & Hai & Hai juga
âž¸ *${prefix}mutual*
Número da Gacha que está no banco de dados / quem usa o bot
         â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
Nota: o resto é para o seu cérebro, só não consigo explicar :)
         â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
ðŸ”° -----[ *FEITO BY ANJOS ID* ]----- ðŸ”°
`
}

exports.cara = cara
