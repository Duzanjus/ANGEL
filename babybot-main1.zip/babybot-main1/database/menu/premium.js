const vip = (pushname, prefix, botName, ownerName, getLevelingLevel, sender, _registered) => {
	return `*࿅᪣ᬼ࿅𝔹𝕆𝕋ீ͜ৡৢ͜͡𝔸ℕ𝕁𝕆𝕊᪣ᬽ

OLÁ, ${pushname} 👋 MEU/MINHA COMPATRIOTA

■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙ＳＯＢＲＥ ＶＯＣÊ
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋╭┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅   
▋┋*NOME : *${pushname}
▋┋*DINHEIRO : Rp:*${uangku}
▋┋*XP : *${reqXp}
▋┋*LEVEL : *${getLevelingLevel(sender)}
▋┋*USUÁRIO : *${botName} : ${_registered.length}
▋┋*NÚMERO : *${sender.split("@")[0]}
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙ＡＪＵＤＡ
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋ Se você não entendeu os comandos, digitar:
▋┋*AJUDA: *${prefix}bingungcok*
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙ＳＯＭＥＮＴＥ ＰＲＥＭＩＵＭ
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋*${prefix}premiumlist*
▋┋*${prefix}randomhentong*
▋┋*${prefix}bokep*
▋┋*${prefix}blowjob*
▋┋*${prefix}nulis1*
▋┋*${prefix}nulis2*
▋┋*${prefix}play*
▋┋*${prefix}mutual*
▋┋*${prefix}next*
▋┋*${prefix}nangis*
▋┋*${prefix}cium*
▋┋*${prefix}peluk*
▋┋*${prefix}tomp3*
▋┋*${prefix}slowmo*
▋┋*${prefix}ngebass*
▋┋*${prefix}gemok*
▋┋*${prefix}tupai*
▋┋*${prefix}hidetag5*
▋┋*${prefix}hidetag10*
▋┋*${prefix}moddroid*
▋┋*${prefix}happymod*
■█■█■█■▰▱▰▱▰▱■█■█■█■

▋┋ *FEITO BY ${ownerName}* ]▋┋`
}
exports.vip = vip