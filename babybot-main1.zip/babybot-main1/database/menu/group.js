const groupm = (pushname, prefix, botName, ownerName, getLevelingLevel, sender, _registered) => {
	return `*࿅᪣ᬼ࿅𝔹𝕆𝕋ீ͜ৡৢ͜͡𝔸ℕ𝕁𝕆𝕊᪣ᬽ

OLÁ, ${pushname} 👋 MEU/MINHA COMPATRIOTA

■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙ＳＯＢＲＥ ＶＯＣÊ
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋╭┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅   
▋┋*NOME : *${pushname}
▋┋*DINHEIRO : Rp:*${uangku}
▋┋*XP : *${reqXp}
▋┋*LEVEL : *${getLevelingLevel(sender)}
▋┋*USUÁRIO : *${botName} : ${_registered.length}
▋┋*NÚMERO : *${sender.split("@")[0]}
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙ＡＪＵＤＡ
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋Se você não entendeu os comandos, digitar:
▋┋*AJUDA: *${prefix}bingungcok*
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙ＰＡＲＡ ＧＲＵＰＯ
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋ *${prefix}welcome* 「1/0」
▋┋ *${prefix}leveling* 「1/0」
▋┋ *${prefix}simih* 「1/0」
▋┋ *${prefix}nsfw* 「1/0」
▋┋ *${prefix}antilinkgrup* 「1/0」
▋┋ *${prefix}grup* 「buka/tutup」
▋┋ *${prefix}add*
▋┋ *${prefix}kick*
▋┋ *${prefix}hedsot*
▋┋ *${prefix}linkgrup*
▋┋ *${prefix}promote*
▋┋ *${prefix}setname*
▋┋ *${prefix}setdesc*
▋┋ *${prefix}leave*
▋┋ *${prefix}tagall*
▋┋ *${prefix}admin*
▋┋ *${prefix}level*
▋┋ *${prefix}fitnah*
▋┋ *${prefix}hidetag*
■█■█■█■▰▱▰▱▰▱■█■█■█■

▋┋ *FEITO BY ${ownerName}* ]▋┋`
}
exports.groupm = groupm
