const simple = (pushname, prefix, botName, ownerName, getLevelingLevel, sender, _registered) => {
	return `*࿅᪣ᬼ࿅𝔹𝕆𝕋ீ͜ৡৢ͜͡𝔸ℕ𝕁𝕆𝕊᪣ᬽ

OLÁ, ${pushname} 👋 MEU/MINHA COMPATRIOTA

■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙ＳＯＢＲＥ ＶＯＣÊ
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋╭┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅   
▋┋*NOME : *${pushname}
▋┋*DINHEIRO : Rp:*${uangku}
▋┋*XP : *${reqXp}
▋┋*LEVEL : *${getLevelingLevel(sender)}
▋┋*USUÁRIO : *${botName} : ${_registered.length}
▋┋*NÚMERO : *${sender.split("@")[0]}
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙ＡＪＵＤＡ
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋ Se você não entendeu os comandos, digitar:
▋┋*AJUDA: *${prefix}bingungcok*
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙+ ＵＴＩＬＩＺＡＤＯＳ
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋ *${prefix}sticker
▋┋ *${prefix}ttp
▋┋ *${prefix}tts
▋┋ *${prefix}nulis
▋┋ *${prefix}toimg
▋┋ *${prefix}stalkig
▋┋ *${prefix}quotes
▋┋ *${prefix}bikinquote
■█■█■█■▰▱▰▱▰▱■█■█■█■

▋┋ *FEITO BY ${ownerName}* ]▋┋`
}
exports.simple = simple
