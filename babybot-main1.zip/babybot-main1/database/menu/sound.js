const sound = (pushname, prefix, botName, ownerName, getLevelingLevel, sender, _registered) => {
	return `*࿅᪣ᬼ࿅𝔹𝕆𝕋ீ͜ৡৢ͜͡𝔸ℕ𝕁𝕆𝕊᪣ᬽ

OLÁ, ${pushname} 👋 MEU/MINHA COMPATRIOTA

■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙ＳＯＢＲＥ ＶＯＣÊ
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋╭┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅   
▋┋*NOME : *${pushname}
▋┋*DINHEIRO : Rp:*${uangku}
▋┋*XP : *${reqXp}
▋┋*LEVEL : *${getLevelingLevel(sender)}
▋┋*USUÁRIO : *${botName} : ${_registered.length}
▋┋*NÚMERO : *${sender.split("@")[0]}
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙ＡＪＵＤＡ
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋ Se você não entendeu os comandos, digitar:
▋┋*AJUDA: *${prefix}bingungcok*
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙ＳＯＵＮＤ / ＳＯＭ
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋ *${prefix}iri
▋┋ *${prefix}pale
▋┋ *${prefix}sound1
▋┋ *${prefix}sound2
▋┋ *${prefix}sound3
▋┋ *${prefix}sound4
▋┋ *${prefix}sound5
▋┋ *${prefix}sound6
▋┋ *${prefix}sound7
▋┋ *${prefix}sound8
▋┋ *${prefix}sound9
▋┋ *${prefix}sound10
■█■█■█■▰▱▰▱▰▱■█■█■█■

▋┋ *FEITO BY ${ownerName}* ]▋┋`
}
exports.sound = sound
