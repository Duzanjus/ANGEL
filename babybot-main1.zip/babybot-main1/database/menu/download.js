const download = (pushname, prefix, botName, ownerName, getLevelingLevel, sender, _registered) => {
	return `*࿅᪣ᬼ࿅𝔹𝕆𝕋ீ͜ৡৢ͜͡𝔸ℕ𝕁𝕆𝕊᪣ᬽ

OLÁ, ${pushname} 👋 MEU/MINHA COMPATRIOTA

■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙ＳＯＢＲＥ ＶＯＣÊ
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋╭┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅   
▋┋*NOME : *${pushname}*
▋┋*DINHEIRO : Rp:*${uangku}*
▋┋*XP : *${reqXp}*
▋┋*LEVEL : *${getLevelingLevel(sender)}*
▋┋*USUÁRIO : *${botName} : *${_registered.length}*
▋┋*NÚMERO : *${sender.split("@")[0]}*
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙ＡＪＵＤＡ
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋ Se você não entendeu os comandos, digitar:
▋┋*AJUDA: *${prefix}bingungcok*
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙ＤＯＷＬＯＡＤ
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋*${prefix}ytmp3*
▋┋*${prefix}yutubdl*
▋┋*${prefix}tiktod*
■█■█■█■▰▱▰▱▰▱■█■█■█■

▋┋ *FEITO BY ${ownerName}* ]▋┋`
}
exports.download = download
